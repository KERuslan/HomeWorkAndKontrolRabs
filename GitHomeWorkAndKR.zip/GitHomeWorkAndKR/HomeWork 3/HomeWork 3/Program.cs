﻿using System;

internal class Program
{
    static void Main()
    {
       

     
        int ReadInt(string message)
        {
            int num;
            Console.Write(message);
            while (!int.TryParse(Console.ReadLine(), out num))
            {
                Console.Write("Ошибка ввода! Введите целое число: ");
            }
            return num;
        }

        // 1. Abs
        Console.WriteLine("Первое задание");
        Console.WriteLine("Abs(-5) = " + Abs(-5));

        // 2. Max3
        Console.WriteLine("Второе задание");
        Console.WriteLine("Max3(2, 7, 5) = " + Max3(2, 7, 5));

        // 3. PrintLine
        Console.WriteLine("Третье задание");
        PrintLine();
        PrintLine("#", 5);
        PrintLine("-", 20);

        // 4. Repeat
        Console.WriteLine("Четвёртое задание");
        Console.WriteLine("Repeat(\"Hi\", 3) = " + Repeat("Hi", 3));

        // 5. TryIndexOf
        Console.WriteLine("Пятое задание");
        if (TryIndexOf("Привет", 'в', out int index))
            Console.WriteLine($"Символ найден, индекс = {index}");
        else
            Console.WriteLine("Символ не найден");

        // 6. Clamp
        Console.WriteLine("Шестое задание");
        int val = ReadInt("Введите число для Clamp: ");
        Clamp(ref val, 0, 10);
        Console.WriteLine("После Clamp: " + val);

        // 7. ReverseRec
        Console.WriteLine("Седьмое задание");
        Console.WriteLine("ReverseRec(\"привет\") = " + ReverseRec("привет"));

        // 8. SumDigitsRec
        Console.WriteLine("Восьмое задание");
        int n = ReadInt("Введите число для суммы цифр: ");
        Console.WriteLine("Сумма цифр: " + SumDigitsRec(n));

        // 9. IsTriangle
        Console.WriteLine("Девятое задание");
        int a = ReadInt("a = ");
        int b = ReadInt("b = ");
        int c = ReadInt("c = ");
        Console.WriteLine("Можно ли составить треугольник: " + IsTriangle(a, b, c));

        // 10. PowFast
        Console.WriteLine("Десятое задание");
        int baseNum = ReadInt("Основание a = ");
        int pow = ReadInt("Степень n = ");
        Console.WriteLine($"PowFast({baseNum}, {pow}) = {PowFast(baseNum, pow)}");

        // 11. CompressRuns
        Console.WriteLine("11-ое задание");
        Console.Write("Введите строку для CompressRuns: ");
        string s = Console.ReadLine();
        Console.WriteLine("После сжатия: " + CompressRuns(s));
    }

    // Методы

    static int Abs(int x)
    {
        return x < 0 ? -x : x;
    }

    static int Max3(int a, int b, int c)
    {
        int max = a;
        if (b > max) max = b;
        if (c > max) max = c;
        return max;
    }

    static void PrintLine(string symbol = "*", int count = 10)
    {
        for (int i = 0; i < count; i++)
            Console.Write(symbol);
        Console.WriteLine();
    }

    static string Repeat(string text, int times = 3)
    {
        string result = "";
        for (int i = 0; i < times; i++)
            result += text;
        return result;
    }

    static bool TryIndexOf(string s, char ch, out int index)
    {
        index = -1;
        for (int i = 0; i < s.Length; i++)
        {
            if (s[i] == ch)
            {
                index = i;
                return true;
            }
        }
        return false;
    }

    static void Clamp(ref int value, int min, int max)
    {
        if (value < min) value = min;
        if (value > max) value = max;
    }

    static string ReverseRec(string s)
    {
        if (s.Length <= 1) return s;
        return s[s.Length - 1] + ReverseRec(s.Substring(0, s.Length - 1));
    }

    static int SumDigitsRec(int n)
    {
        n = Math.Abs(n);
        if (n < 10) return n;
        return n % 10 + SumDigitsRec(n / 10);
    }

    static bool IsTriangle(in int a, in int b, in int c)
    {
        return a + b > c && a + c > b && b + c > a;
    }

    static int PowFast(int a, int n)
    {
        if (n == 0) return 1;
        if (n % 2 == 0)
        {
            int half = PowFast(a, n / 2);
            return half * half;
        }
        else
        {
            return a * PowFast(a, n - 1);
        }
    }

    static string CompressRuns(string s)
    {
        if (string.IsNullOrEmpty(s)) return s;

        string result = "" + s[0];
        for (int i = 1; i < s.Length; i++)
        {
            if (s[i] != s[i - 1])
                result += s[i];
        }
        return result;


        Console.ReadKey();
    }
}

