﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork_4
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Уровень 1");

            Item[] items = new Item[2];
            items[0] = new Item("Меч", 100, 2.5f);
            items[1] = new Item("Щит", 80, 5.0f);

            foreach (var item in items)
            {
                item.DisplayInfo();
            }

            Console.WriteLine("Уровень 2");

            PlayerInventory inventory = new PlayerInventory(5, 15.0f);

            Item item1 = new Item("Зелье здоровья", 50, 0.5f);
            Item item2 = new Item("Золотая монета", 200, 0.1f);
            Item item3 = new Item("Доспехи", 300, 8.0f);
            Item item4 = new Item("Лук", 150, 3.0f);
            Item item5 = new Item("Стрелы", 20, 1.0f);
            Item item6 = new Item("Ключ", 10, 0.2f);
            inventory.AddItem(item1);
            inventory.AddItem(item2);
            inventory.AddItem(item3);
            inventory.AddItem(item4);
            inventory.AddItem(item5);
            inventory.AddItem(item6);
            Console.WriteLine($"Суммарный вес предметов: {inventory.GetTotalWeight()} кг");

            Console.WriteLine("Уровень 3");
            Player player = new Player("Герой", 10, 25.0f);

            Item[] playerItems = 
            {
                new Item("Магический посох", 500, 3.0f),
                new Item("Свиток заклинания", 200, 0.3f),
                new Item("Рубин", 1000, 0.5f),
                new Item("Карта сокровищ", 150, 0.2f),
                new Item("Фляга с водой", 10, 1.0f)
            };

            foreach (var item in playerItems)
            {
                player.PickUpItem(item);
            }
            player.ShowInventory();

            Console.WriteLine($"Общая стоимость инвентаря - {player.GetInventoryValue()} золотых");
        }
    }

    public class Item
    {
        private string name;
        private int price;
        private float weight;
        public Item(string name, int price, float weight)
        {
            this.name = name;
            this.price = price;
            this.weight = weight; }

        public string Name
        {
            get { return name; }
        }

        public int Price
        {
            get { return price; }
        }

        public float Weight
        {
            get { return weight; }
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Предмет: {name}");
            Console.WriteLine($"Цена: {price} золотых");
            Console.WriteLine($"Вес: {weight} кг");
        }
    }
    public class PlayerInventory
    {
        private Item[] items;
        private float weightCapacity;

        public PlayerInventory(int size, float capacity)
        {
            items = new Item[size];
            weightCapacity = capacity;
        }

        public bool AddItem(Item item)
        {
            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] == null)
                {
                    float currentWeight = GetTotalWeight();
                    if (currentWeight + item.Weight > weightCapacity)
                    {
                        Console.WriteLine($"Инвентарь не может вместить предмет '{item.Name}' (требуется {item.Weight} кг, свободно {weightCapacity - currentWeight:F1} кг)");
                        return false;
                    }

                    items[i] = item;
                    Console.WriteLine($"Предмет '{item.Name}' добавлен в инвентарь");
                    return true;
                }
            }

            Console.WriteLine("Инвентарь полон");
            return false;
        }
        public float GetTotalWeight()
        {
            float totalWeight = 0;

            foreach (var item in items)
            {
                if (item != null)
                {
                    totalWeight += item.Weight;
                }
            }

            return totalWeight;
        }
        public int GetTotalPrice()
        {
            int totalPrice = 0;

            foreach (var item in items)
            {
                if (item != null)
                {
                    totalPrice += item.Price;
                }
            }

            return totalPrice;
        }
        public float GetFreeWeight()
        {
            return weightCapacity - GetTotalWeight();
        }
        public void ShowAllItems()
        {
            Console.WriteLine("Содержимое инвентаря:");
            bool hasItems = false;

            for (int i = 0; i < items.Length; i++)
            {
                if (items[i] != null)
                {
                    Console.Write($"[{i}] ");
                    items[i].DisplayInfo();
                    hasItems = true;
                }
            }

            if (!hasItems)
            {
                Console.WriteLine("Инвентарь пуст");
            }

            Console.WriteLine($"Общий вес: {GetTotalWeight():F1}/{weightCapacity} кг");
            Console.WriteLine($"Общая стоимость: {GetTotalPrice()} золотых");
        }
    }
    public class Player
    {

        private string name;
        private PlayerInventory inventory;

        public Player(string playerName, int inventorySize, float inventoryCapacity)
        {
            name = playerName;
            inventory = new PlayerInventory(inventorySize, inventoryCapacity);
        }
        public void PickUpItem(Item item)
        {
            Console.WriteLine($"{name} пытается поднять {item.Name}...");
            inventory.AddItem(item);
        }

        public void ShowInventory()
        {
            Console.WriteLine($"Инвентарь игрока {name}");
            inventory.ShowAllItems();
        }

        public int GetInventoryValue()
        {
            return inventory.GetTotalPrice();
        }
        public float GetInventoryWeight()
        {
            return inventory.GetTotalWeight();
        }
    }
}
