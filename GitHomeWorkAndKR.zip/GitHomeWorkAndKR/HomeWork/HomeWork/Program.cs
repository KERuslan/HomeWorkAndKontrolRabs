﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //0
            Console.WriteLine("Hello, World!");

            //1
            int a;
            int b;
            Console.WriteLine("Первое число");
            a = int.Parse(Console.ReadLine());
            Console.WriteLine("Второе число");
            b = int.Parse(Console.ReadLine());
            Console.Write($"Сложение {a + b}, Вычмтание {a - b}, Произведение {a * b}, ");

            if (b != 0)

            {
                Console.WriteLine($"Частное {a / (float)b}");
            }
            else
            { Console.WriteLine("ошибка в делении"); }

            //2
            int v;
            Console.WriteLine("Возраст");
            v = int.Parse(Console.ReadLine());
            bool v1 = 12 < v;
            if (v < 12)
            {
                Console.WriteLine("Ребёнок");
            }

            else if (v1 && (v < 17))
            { Console.WriteLine("Подросток"); }

            else
            { Console.WriteLine("Взрослый"); }


            //3

            int c;

            Console.WriteLine("Введите число");

            c = int.Parse(Console.ReadLine());

            if (c % 2 != 0)

            { Console.WriteLine("Нечётное"); }
            else
            {
                Console.WriteLine("Чётное");
            }
            //4

            int n;

            Console.WriteLine("Введите число");

            n = int.Parse(Console.ReadLine());


            if ((n % 3 == 0) && (n % 5 == 0))




            { Console.WriteLine("Делится"); }

            else { Console.WriteLine("Не делится"); }

            //5 

            int m;

            int sum = 0;
            Console.WriteLine("Введите число");

            m = int.Parse(Console.ReadLine());

            for (int i = 0; i < m; i++) { sum += i + 1; }

            Console.WriteLine(sum);

            //6

            int t;

            Console.WriteLine("Введите число");

            t = int.Parse(Console.ReadLine());

            for (int i = 1; i <= 10; i++)
            {
                Console.WriteLine($"{i}*{t}={i * t}");
            }

            //7

            int l;
            int finish = 1;

            Console.WriteLine("Введите число");

            l = int.Parse(Console.ReadLine());

            for (int i = 1; i <= l; i++)
            {
                finish *= i;
            }
            Console.WriteLine($"Факториал {l} - {finish}");


            //8

            string ps = "12345";

            string p;

            Console.WriteLine("Введите пароль");

            p = Console.ReadLine();

            while (p != ps)
            { p = Console.ReadLine(); }
            Console.WriteLine("Пароль верный!");

            //9

            int k;

            Console.WriteLine("Введите число");

            k = int.Parse(Console.ReadLine());

            for (int i = 1; i <= k; i++)

                if ((i % 2 == 0) || (i % 3 == 0))
                {
                    Console.WriteLine(i);
                }

            //11
            Console.WriteLine("Игра");
            Random B = new Random();
            int R = B.Next(10);
            int zd11 = int.Parse(Console.ReadLine());

            while (zd11 != R)
            {
                if (zd11 < R)
                {
                    Console.WriteLine("Больше");
                }
                else
                {
                    Console.WriteLine("Меньше");
                }
                zd11 = int.Parse(Console.ReadLine());
            }
            Console.WriteLine("Верно!");
                Console.ReadKey();

            } 
        }
}
