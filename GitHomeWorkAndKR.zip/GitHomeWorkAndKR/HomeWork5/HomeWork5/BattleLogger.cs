﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork5
{
    public static class BattleLogger
    {
        private static List<string> log = new List<string>();

        public static void Log(string message)
        {
            log.Add(message);
            Console.WriteLine(message);
        }

        public static void DisplayBattleSummary()
        {
            Console.WriteLine("Сводка боя:");
            foreach (var entry in log)
            {
                Console.WriteLine(entry);
            }
        }

        public static void Clear()
        {
            log.Clear();
        }
    }
}
