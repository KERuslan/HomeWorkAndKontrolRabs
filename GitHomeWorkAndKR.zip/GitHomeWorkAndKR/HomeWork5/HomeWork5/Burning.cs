﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{
    public class Burning : Effect
    {
        public Burning()
        {
            Name = "Горение";
            Duration = 3;
        }

        public override void OnApply(Character target)
        {
            BattleLogger.Log($"{target.Name} начинает гореть! Длительность: {Duration} ходов");
        }

        public override void ProcessTurn(Character target)
        {
            target.TakeDamage(5);
            Duration--;

            if (Duration > 0)
                BattleLogger.Log($"{target.Name} горит! Осталось ходов: {Duration}");
        }

        public override void OnExpire(Character target)
        {
            BattleLogger.Log($"{target.Name} перестал гореть");
        }
    }
}
