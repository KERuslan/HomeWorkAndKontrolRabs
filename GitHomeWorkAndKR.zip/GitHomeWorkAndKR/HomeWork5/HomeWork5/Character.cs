﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{
    public abstract class Character
    {
        public string Name { get; protected set; }
        public int CurrentHealth { get; protected set; }
        public int MaxHealth { get; protected set; }
        public bool IsAlive { get; protected set; }
        public List<Effect> ActiveEffects { get; protected set; }

        protected Character(string name, int maxHealth)
        {
            Name = name;
            MaxHealth = maxHealth;
            CurrentHealth = maxHealth;
            IsAlive = true;
            ActiveEffects = new List<Effect>();
        }

        public virtual void TakeDamage(int damage)
        {
            if (!IsAlive) return;

            bool hasShield = ActiveEffects.Exists(effect => effect is Shielded);
            if (hasShield)
            {
                damage = (int)(damage * 0.5);
                BattleLogger.Log($"Защита поглощает часть урона! Новый урон: {damage}");
            }

            int actualDamage = CalculateActualDamage(damage);
            CurrentHealth -= actualDamage;

            BattleLogger.Log($"{Name} получает {actualDamage} урона. Здоровье: {CurrentHealth}/{MaxHealth}");

            if (CurrentHealth <= 0)
            {
                CurrentHealth = 0;
                IsAlive = false;
                BattleLogger.Log($"{Name} погиб!");
            }
        }

        protected virtual int CalculateActualDamage(int damage)
        {
            return damage;
        }

        public virtual void Heal(int amount)
        {
            if (!IsAlive) return;

            CurrentHealth += amount;
            if (CurrentHealth > MaxHealth)
                CurrentHealth = MaxHealth;

            BattleLogger.Log($"{Name} восстанавливает {amount} здоровья. Здоровье: {CurrentHealth}/{MaxHealth}");
        }

        public void ProcessEffects()
        {
            for (int i = ActiveEffects.Count - 1; i >= 0; i--)
            {
                var effect = ActiveEffects[i];
                effect.ProcessTurn(this);

                if (effect.Duration <= 0)
                {
                    effect.OnExpire(this);
                    ActiveEffects.RemoveAt(i);
                }
            }
        }

        public void AddEffect(Effect effect)
        {
            ActiveEffects.Add(effect);
            effect.OnApply(this);
        }
    }
}


