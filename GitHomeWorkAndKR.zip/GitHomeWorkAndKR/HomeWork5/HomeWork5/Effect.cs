﻿using HomeWork5;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork5
{
    public abstract class Effect
    {
        public string Name { get; protected set; }
        public int Duration { get; protected set; }

        public abstract void OnApply(Character target);
        public abstract void ProcessTurn(Character target);
        public abstract void OnExpire(Character target);
    }
}