﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{
    public class Fireball : Spell
    {
        private Random random = new Random();

        public Fireball()
        {
            Name = "Огненный шар";
            Description = "Наносит 15-25 урона, с шансом поджечь цель";
            Cooldown = 2;
        }

        public override void Cast(Character caster, Character target)
        {
            int damage = random.Next(15, 26);
            target.TakeDamage(damage);

          
            if (random.Next(0, 2) == 0)
            {
                target.AddEffect(new Burning());
            }
        }
    }
}
