﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{

public class Goblin : Character
    {
     public Goblin(string name) : base(name, 80) { }

       protected override int CalculateActualDamage(int damage)
       {
               
          return damage > 0 ? damage - 1 : 0;
       }
    }
}

