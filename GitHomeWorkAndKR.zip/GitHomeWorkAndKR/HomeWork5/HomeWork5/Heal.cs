﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;


namespace HomeWork5
{
    public class Heal : Spell
    {
        private Random random = new Random();

        public Heal()
        {
            Name = "Лечение";
            Description = "Восстанавливает 10-20 здоровья";
            Cooldown = 3;
        }

        public override void Cast(Character caster, Character target)
        {
            int healAmount = random.Next(10, 21);
            target.Heal(healAmount);
        }
    }
}
