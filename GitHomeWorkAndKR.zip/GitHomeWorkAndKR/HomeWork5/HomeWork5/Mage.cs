﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{

public class Mage : Character
{
    public List<Spell> Spellbook { get; private set; }

        public Mage(string name) : base(name, 100)
        {
            Spellbook = new List<Spell>
            {
                new Fireball(),
                new Heal(),
                new ShieldSpell()
            };
        }

    public void CastSpell(int spellIndex, Character target)
    {
        if (spellIndex < 0 || spellIndex >= Spellbook.Count)
        {
            BattleLogger.Log("Неверный номер заклинания");
            return;
        }

    var spell = Spellbook[spellIndex];

        if (spell.IsOnCooldown)
        {
            BattleLogger.Log($"Заклинание {spell.Name} на перезарядке! Осталось ходов: {spell.RemainingCooldown}");
            return;
        }

            BattleLogger.Log($"{Name} использует {spell.Name} на {target.Name}");
                spell.Cast(this, target);
                spell.StartCooldown();
        }
   }
}


