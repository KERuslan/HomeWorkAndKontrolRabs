﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork5
{
    public class Game
    {
        private Mage mage;
        private Goblin goblin;
        private Random random = new Random();

        public void Start()
        {
            InitializeCharacters();
            BattleLoop();
            ShowResults();
        }

        private void InitializeCharacters()
        {
            Console.Write("Введите имя мага: ");
            string mageName = GetNonEmptyInput("Имя не может быть пустым! Введите имя мага: ");

            Console.Write("Введите имя гоблина: ");
            string goblinName = GetNonEmptyInput("Имя не может быть пустым! Введите имя гоблина: ");

            mage = new Mage(mageName);
            goblin = new Goblin(goblinName);

            Console.WriteLine($"{mage.Name} (Здоровье: {mage.MaxHealth})");
            Console.WriteLine($"{goblin.Name} (Здоровье: {goblin.MaxHealth})");
            Console.WriteLine();
        }

        private void BattleLoop()
        {
            int round = 1;

            while (mage.IsAlive && goblin.IsAlive)
            {
                Console.WriteLine($"РАУНД {round}");
                MageTurn();
                if (!goblin.IsAlive) break;

                ProcessAllEffects();
                if (!mage.IsAlive || !goblin.IsAlive) break;

                GoblinTurn();
                if (!mage.IsAlive) break;

                ProcessAllEffects();

                ReduceSpellCooldowns();

                round++;
            }
        }

        private void MageTurn()
        {
            Console.WriteLine($"Ход {mage.Name}:");
            DisplaySpellbook();

            int spellChoice = GetValidInput("Выберите заклинание (0-2): ", 0, 2);
            Character target = goblin; 
            if (spellChoice == 1 || spellChoice == 2) 
            {
                target = mage;
            }

            mage.CastSpell(spellChoice, target);
        }

        private void GoblinTurn()
        {
            Console.WriteLine($"Ход {goblin.Name}:");
            int damage = random.Next(8, 15);
            mage.TakeDamage(damage);
        }

        private void ProcessAllEffects()
        {
            Console.WriteLine("Обработка эффектов:");
            mage.ProcessEffects();
            goblin.ProcessEffects();
        }

        private void ReduceSpellCooldowns()
        {
            foreach (var spell in mage.Spellbook)
            {
                spell.ReduceCooldown();
            }
        }

        private void DisplaySpellbook()
        {
            Console.WriteLine("Книга заклинаний:");
            for (int i = 0; i < mage.Spellbook.Count; i++)
            {
                Console.Write($"{i}. ");
                mage.Spellbook[i].DisplayInfo();
            }
        }

        private void ShowResults()
        {
            Console.WriteLine("Бой завершен!");
            if (mage.IsAlive)
                Console.WriteLine($"Победил {mage.Name}!");
            else
                Console.WriteLine($"Победил {goblin.Name}!");

            BattleLogger.DisplayBattleSummary();
        }

        private int GetValidInput(string prompt, int min, int max)
        {
            while (true)
            {
                Console.Write(prompt);
                if (int.TryParse(Console.ReadLine(), out int result) && result >= min && result <= max)
                {
                    return result;
                }
                Console.WriteLine($"Пожалуйста, введите число от {min} до {max}");
            }
        }

        private string GetNonEmptyInput(string errorMessage)
        {
            string input;
            do
            {
                input = Console.ReadLine();
                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine(errorMessage);
                }
            } while (string.IsNullOrWhiteSpace(input));

            return input.Trim();
        }
    }
}
