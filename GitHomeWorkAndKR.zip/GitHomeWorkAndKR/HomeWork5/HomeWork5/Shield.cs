﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork5
{
    public class ShieldSpell : Spell
    {
        public ShieldSpell()
        {
            Name = "Щит";
            Description = "Накладывает защиту на 3 хода, уменьшающую урон";
            Cooldown = 4;
        }

        public override void Cast(Character caster, Character target)
        {
            caster.AddEffect(new Shielded());
        }
    }
}
