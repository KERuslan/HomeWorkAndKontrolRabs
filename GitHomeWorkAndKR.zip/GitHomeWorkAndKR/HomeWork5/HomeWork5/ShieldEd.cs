﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{
    public class Shielded : Effect
    {
        public Shielded()
        {
            Name = "Защита";
            Duration = 3;
        }

        public override void OnApply(Character target)
        {
            BattleLogger.Log($"{target.Name} получает защиту! Длительность: {Duration} ходов");
        }

        public override void ProcessTurn(Character target)
        {
            Duration--;

            if (Duration > 0)
                BattleLogger.Log($"{target.Name} под защитой. Осталось ходов: {Duration}");
        }

        public override void OnExpire(Character target)
        {
            BattleLogger.Log($"Защита {target.Name} закончилась");
        }
    }
}
