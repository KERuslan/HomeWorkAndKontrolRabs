﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace HomeWork5
{
public abstract class Spell
    {
        public string Name { get; protected set; }
        public string Description { get; protected set; }
        public int Cooldown { get; protected set; }
        public int RemainingCooldown { get; protected set; }
        public bool IsOnCooldown => RemainingCooldown > 0;

        public abstract void Cast(Character caster, Character target);

        public void StartCooldown()
        {
            RemainingCooldown = Cooldown;
        }

        public void ReduceCooldown()
        {
            if (RemainingCooldown > 0)
                RemainingCooldown--;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"{Name}: {Description}");
            if (IsOnCooldown)
                Console.WriteLine($"Перезарядка: {RemainingCooldown} ходов");
        }
    }
}
