﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
    class Character
    {
        public string Name { get; set; }
        public int Health { get; set; }
        public int MaxHealth { get; set; }
        public int Energy { get; set; }
        public int MaxEnergy { get; set; }
        public int Gold { get; set; }
        public Weapon EquippedWeapon { get; set; }
        public Armor EquippedArmor { get; set; }
        public Ring EquippedRing { get; set; }

        public Character(string name, int maxHealth, int maxEnergy, int startGold)
        {
            if (string.IsNullOrEmpty(name))
            {
                Name = "Безымянный";
                Console.WriteLine("Имя не может быть пустым. Установлено имя 'Безымянный'");
            }
            else
            {
                Name = name;
            }

            if (maxHealth <= 0)
            {
                MaxHealth = 100;
                Console.WriteLine("Максимальное здоровье должно быть больше 0. Установлено 100.");
            }
            else
            {
                MaxHealth = maxHealth;
            }

            if (maxEnergy <= 0)
            {
                MaxEnergy = 50;
                Console.WriteLine("Максимальная энергия должна быть больше 0. Установлено 50.");
            }
            else
            {
                MaxEnergy = maxEnergy;
            }

            Health = MaxHealth;
            Energy = MaxEnergy;

            if (startGold < 0)
            {
                Gold = 0;
                Console.WriteLine("Начальное золото не может быть отрицательным. Установлено 0.");
            }
            else
            {
                Gold = startGold;
            }
        }

        public void AddHealth(int value)
        {
            Health += value;
            if (Health > MaxHealth)
                Health = MaxHealth;
            if (Health < 0)
                Health = 0;

            Console.WriteLine($"Здоровье изменено: {Health}/{MaxHealth}");
        }

        public void AddEnergy(int value)
        {
            Energy += value;
            if (Energy > MaxEnergy)
                Energy = MaxEnergy;
            if (Energy < 0)
                Energy = 0;

            Console.WriteLine($"Энергия изменена: {Energy}/{MaxEnergy}");
        }

        public void AddGold(int value)
        {
            int newGold = Gold + value;
            if (newGold < 0)
            {
                Console.WriteLine("Нельзя иметь отрицательное количество золота");
                return;
            }

            Gold = newGold;
            Console.WriteLine($"Золото изменено: {Gold}");
        }

        public void EquipWeapon(Weapon weapon)
        {
            if (weapon == null)
            {
                Console.WriteLine("Нельзя экипировать пустое оружие");
                return;
            }

            EquippedWeapon = weapon;
            Console.WriteLine($"Экипировано оружие: {weapon.Name}");
        }

        public void EquipArmor(Armor armor)
        {
            if (armor == null)
            {
                Console.WriteLine("Нельзя экипировать пустую броню");
                return;
            }

            EquippedArmor = armor;
            Console.WriteLine($"Экипирована броня: {armor.Name}");
        }

        public void EquipRing(Ring ring)
        {
            if (ring == null)
            {
                Console.WriteLine("Нельзя экипировать пустое кольцо");
                return;
            }

            EquippedRing = ring;
            Console.WriteLine($"Экипировано кольцо: {ring.Name}");
        }

        public void UnequipWeapon()
        {
            if (EquippedWeapon == null)
            {
                Console.WriteLine("Оружие и так не экипировано");
                return;
            }

            Console.WriteLine($"Снято оружие: {EquippedWeapon.Name}");
            EquippedWeapon = null;
        }

        public void UnequipArmor()
        {
            if (EquippedArmor == null)
            {
                Console.WriteLine("Броня и так не экипирована");
                return;
            }

            Console.WriteLine($"Снята броня: {EquippedArmor.Name}");
            EquippedArmor = null;
        }

        public void UnequipRing()
        {
            if (EquippedRing == null)
            {
                Console.WriteLine("Кольцо и так не экипировано");
                return;
            }

            Console.WriteLine($"Снято кольцо: {EquippedRing.Name}");
            EquippedRing = null;
        }

        public void ShowInfo()
        {
            Console.WriteLine("Ваш персонаж:");
            Console.WriteLine($"Имя: {Name}");
            Console.WriteLine($"Здоровье: {Health}/{MaxHealth}");
            Console.WriteLine($"Энергия: {Energy}/{MaxEnergy}");
            Console.WriteLine($"Золото: {Gold}");

            string weapon = EquippedWeapon != null ? EquippedWeapon.Name : "нет";
            string armor = EquippedArmor != null ? EquippedArmor.Name : "нет";
            string ring = EquippedRing != null ? EquippedRing.Name : "нет";

            Console.WriteLine($"Оружие: {weapon}");
            Console.WriteLine($"Броня: {armor}");
            Console.WriteLine($"Кольцо: {ring}");
        }
    }
}
