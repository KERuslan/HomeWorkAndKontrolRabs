﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class Food : Item, IUsable
{
    public Food() : base("Еда", "Восстанавливает 15 энергии") { }

    public void Use(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddEnergy(15);
        Console.WriteLine("Еда съедена");
    }
}
}
