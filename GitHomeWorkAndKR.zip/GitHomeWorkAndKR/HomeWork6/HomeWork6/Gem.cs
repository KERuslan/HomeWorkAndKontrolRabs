﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class Gem : Item, ISellable
{
    public int Price => 50;

    public Gem() : base("Драгоценный камень", "Можно продать за 50 золотых") { }

    public void Sell(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddGold(Price);
        Console.WriteLine($"Продан драгоценный камень за {Price} золотых");
    }
}
}
