﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
 class HealthPotion : Item, IUsable
{
    public HealthPotion() : base("Зелье здоровья", "Восстанавливает 20 здоровья") { }

    public void Use(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddHealth(20);
        Console.WriteLine("Использовано зелье здоровья");
    }
}
}
