﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
    class Inventory
    {
        private List<Item> items;
        private int maxSize;

        public Inventory(int maxSize)
        {
            if (maxSize <= 0)
            {
                Console.WriteLine("Размер инвентаря должен быть больше 0. Установлен размер 10.");
                this.maxSize = 10;
            }
            else
            {
                this.maxSize = maxSize;
            }
            items = new List<Item>();
        }

        public bool Add(Item item)
        {
            if (item == null)
            {
                Console.WriteLine("Нельзя добавить пустой предмет");
                return false;
            }

            if (items.Count >= maxSize)
            {
                Console.WriteLine("Инвентарь полон. Нельзя добавить новый предмет.");
                return false;
            }

            items.Add(item);
            Console.WriteLine($"Предмет '{item.Name}' добавлен в инвентарь");
            return true;
        }

        public void RemoveAt(int index)
        {
            if (index < 0 || index >= items.Count)
            {
                Console.WriteLine($"Индекс {index} вне диапазона инвентаря");
                return;
            }

            string itemName = items[index].Name;
            items.RemoveAt(index);
            Console.WriteLine($"Предмет '{itemName}' удален из инвентаря");
        }

        public Item GetItem(int index)
        {
            if (index < 0 || index >= items.Count)
            {
                Console.WriteLine($"Индекс {index} вне диапазона инвентаря");
                return null;
            }

            return items[index];
        }

        public void ShowInventory()
        {
            Console.WriteLine("Инвентарь:");
            if (items.Count == 0)
            {
                Console.WriteLine("Пусто");
                return;
            }

            for (int i = 0; i < items.Count; i++)
            {
                Console.Write($"[{i}] ");
                items[i].ShowInfo();
            }
            Console.WriteLine($"Свободно мест: {maxSize - items.Count}/{maxSize}");
        }
    }
}
