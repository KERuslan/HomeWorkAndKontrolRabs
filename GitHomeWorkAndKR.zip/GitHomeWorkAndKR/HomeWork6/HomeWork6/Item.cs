﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class Item
{
    public string Name { get; set; }
    public string Description { get; set; }

    public Item(string name, string description)
    {
        if (string.IsNullOrEmpty(name))
        {
            Name = "Безымянный предмет";
            Console.WriteLine("Имя предмета не может быть пустым");
        }
        else
        {
            Name = name;
        }
        
        Description = description ?? "Описание отсутствует";
    }

    public virtual void ShowInfo()
    {
        Console.WriteLine($"{Name} - {Description}");
    }
}
}
