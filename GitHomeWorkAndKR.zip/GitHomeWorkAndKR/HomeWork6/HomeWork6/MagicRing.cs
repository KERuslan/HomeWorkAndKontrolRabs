﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class MagicRing : Ring, ISellable
{
    public int Price => 100;

    public MagicRing() : base("Магическое кольцо", "Повышает магическую силу") { }

    public void Sell(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddGold(Price);
        Console.WriteLine($"Продан магическое кольцо за {Price} золотых");
    }
}
}
