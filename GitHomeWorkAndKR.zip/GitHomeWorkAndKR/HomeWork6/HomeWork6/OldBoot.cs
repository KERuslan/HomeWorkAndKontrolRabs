﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class OldBoot : Item, IDiscardable
{
    public OldBoot() : base("Старый ботинок", "Никому не нужен") { }

    public void Discard()
    {
        Console.WriteLine("Старый ботинок выброшен");
    }
}
}
