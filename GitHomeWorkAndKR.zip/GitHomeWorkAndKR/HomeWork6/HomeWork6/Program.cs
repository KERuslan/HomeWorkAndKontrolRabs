﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
    class Program
    {
        static void Main()
        {
            Character character = new Character("Герой", 100, 50, 0);
            Inventory inventory = new Inventory(10);


            inventory.Add(new HealthPotion());
            inventory.Add(new Food());
            inventory.Add(new Gem());
            inventory.Add(new OldBoot());
            inventory.Add(new Weapon("Меч", "Обычный стальной меч"));
            inventory.Add(new Armor("Кольчуга", "Простая кольчуга"));
            inventory.Add(new MagicRing());
            inventory.Add(new Scroll());

            while (true)
            {
                Console.Clear();
                character.ShowInfo();
                Console.WriteLine();

                inventory.ShowInventory();
                Console.WriteLine();

                Console.WriteLine("Выберите действие:");
                Console.WriteLine("1 - Использовать предмет");
                Console.WriteLine("2 - Экипировать предмет");
                Console.WriteLine("3 - Продать предмет");
                Console.WriteLine("4 - Выбросить предмет");
                Console.WriteLine("0 - Выход");

                string choice = Console.ReadLine();

                if (string.IsNullOrEmpty(choice))
                {
                    Console.WriteLine("Ошибка! Введите число от 0 до 4");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    Console.ReadKey();
                    continue;
                }

                if (choice == "0")
                {
                    Console.WriteLine("Выход из программы");
                    break;
                }

                if (choice != "1" && choice != "2" && choice != "3" && choice != "4")
                {
                    Console.WriteLine("Ошибка! Выберите число от 0 до 4");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    Console.ReadKey();
                    continue;
                }

                Console.Write("Введите индекс предмета: ");
                string indexInput = Console.ReadLine();

                if (string.IsNullOrEmpty(indexInput))
                {
                    Console.WriteLine("Индекс не может быть пустым");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    Console.ReadKey();
                    continue;
                }

                if (!int.TryParse(indexInput, out int index))
                {
                    Console.WriteLine("Введите целое число");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    Console.ReadKey();
                    continue;
                }

                Item item = inventory.GetItem(index);
                if (item == null)
                {
                    Console.WriteLine("Предмета с таким индексом не существует");
                    Console.WriteLine("Нажмите любую клавишу для продолжения");
                    Console.ReadKey();
                    continue;
                }

                bool actionSuccess = false;

                switch (choice)
                {
                    case "1":
                        if (item is IUsable usable)
                        {
                            usable.Use(character);
                            actionSuccess = true;
                        }
                        else
                        {
                            Console.WriteLine("Этот предмет нельзя использовать");
                        }
                        break;

                    case "2":
                        if (item is IEquipable equipable)
                        {
                            equipable.Equip(character);
                            actionSuccess = true;
                        }
                        else
                        {
                            Console.WriteLine("Этот предмет нельзя экипировать");
                        }
                        break;

                    case "3":
                        if (item is ISellable sellable)
                        {
                            sellable.Sell(character);
                            inventory.RemoveAt(index);
                            actionSuccess = true;
                        }
                        else
                        {
                            Console.WriteLine("Этот предмет нельзя продать");
                        }
                        break;

                    case "4":
                        if (item is IDiscardable discardable)
                        {
                            discardable.Discard();
                            inventory.RemoveAt(index);
                            actionSuccess = true;
                        }
                        else
                        {
                            Console.WriteLine("Этот предмет нельзя выбросить");
                        }
                        break;
                }

                if (actionSuccess)
                {
                    Console.WriteLine("Действие выполнено успешно");
                }

                Console.WriteLine("Нажмите любую клавишу для продолжения");
                Console.ReadKey();
            }
        }
    }
}
