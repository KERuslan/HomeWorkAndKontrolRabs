﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HomeWork6
{
class Scroll : Item, IUsable, ISellable
{
    public int Price => 30;

    public Scroll() : base("Свиток", "Магический свиток с заклинанием, может восстановить энергию") { }

    public void Use(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddEnergy(10);
        Console.WriteLine("Использован свиток");
    }

    public void Sell(Character user)
    {
        if (user == null)
        {
            Console.WriteLine("Персонаж не существует");
            return;
        }
        
        user.AddGold(Price);
        Console.WriteLine($"Продан свиток за {Price} золотых");
    }
}
}
