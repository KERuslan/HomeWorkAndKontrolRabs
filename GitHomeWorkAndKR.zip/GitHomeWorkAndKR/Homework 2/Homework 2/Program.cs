﻿using System;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;

namespace Homework_2
{
    internal class Program
    {
        static void Main(string[] args)
        {


            ////1

            //Console.WriteLine("Задание 1");

            //Console.WriteLine("Ведите число");
            //string newString = Console.ReadLine();
            //int newint = int.Parse(newString);

            //newint = newint + 100;

            //Console.WriteLine(newint);


            ////2
            //Console.WriteLine("Задание 2");
            //if ((double)7 / 2 > (int)7.0 / 2)
            //Console.WriteLine($"{(double)7 / 2}"); 
            //Console.WriteLine($"{(int)7.0 / 2}"); 

            ////3

            //Console.WriteLine("Задание 3");
            //Console.WriteLine("Ведите число");
            //string Sin = Console.ReadLine();

            //if (int.TryParse(Sin, out int Ink))
            //{
            //    Console.WriteLine(Ink * Ink);
            //}
            //else
            //{
            //    Console.WriteLine("Ошибка ввода");
            //}

            ////4


            //Console.WriteLine("Задание 4");
            //Console.WriteLine("Ведите число");

            //double Sim = double.Parse(Console.ReadLine());

            //int Lim = (int)Sim;

            //Console.WriteLine($"Разница между величинами - {(Sim - Lim)}");

            ////5

            //Console.WriteLine("Задание 5");
            //int[] op = new int[5] { 3, 7, 4, 5, 7 };

            //for (int i = 0; i < op.Length; i++)
            //{ Console.Write(op[i]); }
            //Console.WriteLine(" ");

            ////6

            //Console.WriteLine("Задание 6");
            //int exp = 0;
            //int[] xp = new int[5] { 6, 7, 4, 5, 8 };


            //{
            //    for (int i = 0; i < xp.Length; i++)
            //    {
            //        if (xp[i] % 2 == 0)
            //        { exp++; }
            //    }


            //}
            //Console.WriteLine(exp);
            ////7

            //Console.WriteLine("Задание 7");

            //int sm = 0;
            //int[] cp = new int[5] { 6, 7, 4, 5, 8 };

            //{
            //    for (int i = 0; i < cp.Length; i++)

            //        sm += cp[i];



            //}

            //double am = (double)sm / cp.Length;
            //Console.WriteLine($"Сумма - {sm}");
            //Console.WriteLine($"Сумма - {am}");


            ////8
            //Console.WriteLine("Задание 8");


            //int[] cet = new int[5] { 9, 6, 3, 1, 2 };


            //for (int i = 0; i < cet.Length; i++)
            //{ Console.Write(cet[i]); }
            //Console.WriteLine(" ");

            //int let = cet[0];

            //cet[0] = cet[cet.Length - 1];
            //cet[cet.Length - 1] = let;




            //for (int i = 0; i < cet.Length; i++)

            //{ Console.Write(cet[i]); }
            //Console.WriteLine(" ");

            ////9

            //Console.WriteLine("Задание 9");

            //int[] ix = new int[5] { 1, 2, 3, 4, 5 };

            //for (int i = 0; i < ix.Length; i++)
            //{
            //    Console.Write(ix[i]);
            //}
            //Console.WriteLine(" ");

            //int minV = ix[0];
            //int maxV = ix[0];

            //int minI = 0;
            //int maxI = 0;

            //for (int i = 0; i < ix.Length; i++)
            //{
            //    if (minV > ix[i])
            //    {
            //        minV = ix[i];
            //        minI = i;
            //    }
            //    if (maxV < ix[i])
            //    {
            //        maxV = ix[i];
            //        maxI = i;
            //    }
            //}

            //Console.WriteLine($"{ix[minI]} - {minI}");
            //Console.WriteLine($"{ix[maxI]} - {maxI}");


            ////10
            //Console.WriteLine("Задание 10");
            //int[] kl = new int[10];
            //int count = 5;
            //Console.WriteLine("Введите массив");
            //for (int i = 0; i < count; i++)

            //{
            //    kl[i] = int.Parse(Console.ReadLine());
            //}
            //Console.WriteLine("Добавьте");
            //int nm = int.Parse(Console.ReadLine());
            //if (count <  kl.Length)
            //{
            //    kl[count] = nm;
            //    count++;
            //}
            //else
            //{
            //    int[] mn = new int[kl.Length * 2];
            //    for (int i = 0; i < kl.Length; i++)
            //    {
            //        mn[i] = kl[i];
            //    }
            //    kl = mn;}
            //for (int i = 0; i < kl.Length; i++)
            //{
            //    Console.Write(kl[i]);
            //}
            //Console.WriteLine(" ");


     


            ////11

            //Console.WriteLine("Задание 11");

            //int[] pp = new int[5] { 1, 2, 3, 4, 5 };

            //for (int i = 0; i < pp.Length; i++)
            //{
            //    Console.Write(pp[i]);
            //}
            //Console.WriteLine(" ");

            //int pc = int.Parse(Console.ReadLine());

            //for (int i = pc + 1; i < pp.Length; i++)

            //{
            //    pp[i - 1] = pp[i];
            //}
            //pp[pp.Length - 1] = 0;
            //for (int i = 0; i < pp.Length; i++)
            //{
            //    Console.Write(pp[i]);
            //}
            //Console.WriteLine(" ");

            ////12

            //Console.WriteLine("Задание 12");

            //int[] ll = new int[5] { 6, 2, 4, 3, 7 };

            //for (int i = 0; i < ll.Length; i++)
            //{
            //    Console.Write(ll[i]);
            //}
            //Console.WriteLine(" ");

            //int lp = int.Parse(Console.ReadLine());

            //ll[lp] = ll[ll.Length - 1];

            //ll[ll.Length - 1] = 0;

            //for (int i = 0; i < ll.Length; i++)
            //{
            //    Console.Write(ll[i]);
            //}
            //Console.WriteLine(" ");

            ////13

            //Console.WriteLine("Задание 13");

            //int[] kx = new int[6] { 1, 5, 3, 5, 2, 5 };

            //for (int i = 0; i < kx.Length; i++)
            //{
            //    Console.Write(kx[i]);
            //}
            //Console.WriteLine(" ");

            //int xk = int.Parse(Console.ReadLine());
            //for (int i = 0; i < kx.Length - 1; i++)
            //{
            //    if (kx[i] == xk)
            //    {

            //        for (int j = i; j < kx.Length - 1; j++)
            //        {
            //            kx[j] = kx[j + 1];
            //        }
            //        kx[kx.Length - 1] = 0;
            //        i--;
            //    }
            //}

            //for (int i = 0; i < kx.Length; i++)
            //{
            //    Console.Write(kx[i]);
            //}
            //Console.WriteLine(" ");

            ////14 

            //Console.WriteLine("Задание 14");

            //int[] mp = new int[5] {5, 4, 3, 2, 1};
       
            //for (int i = 0; i < mp.Length; i++)
            //{
            //    Console.Write(mp[i]);
            //}
            //Console.WriteLine(" ");

            //int[] np = new int[5];
            //for (int i = 0; i < mp.Length; i++)
            //{
            //    np[i] = mp[mp.Length - 1 - i];
            //}

            //for (int i = 0; i < np.Length; i++)
            //{
            //    Console.Write(np[i]);
            //}
            //Console.WriteLine(" ");

            

            //15

            Console.WriteLine("Задание 15");

            int[] nmb = new int[6] {4, 2, 3, 3, 2, 4 };
            int[] rnmb = new int[nmb.Length];
            int pst = 0;

            for (int i = nmb.Length - 1; i >= 0; i--)
            {
                rnmb[pst] = nmb[i];
                pst++;
            }


            pst = 0;
            int mco = 0;

            for (int i = rnmb.Length - 1; i >= 0; i--)
            {

                if (nmb[i] == nmb[pst])
                {
                    mco++;
                }
                pst++;
            }


            if (mco == nmb.Length)
            {
                Console.WriteLine($"Массив [{string.Join(", ", nmb)}] - палиндром");
            }
            else
            {
                Console.WriteLine($"Массив [{string.Join(", ", nmb)}] - не палиндром");
            }

            //16

            Console.WriteLine("Задание 16");

            Console.WriteLine("Введите длину");
            int arl = int.Parse(Console.ReadLine());


            int[] nar = new int[arl];


            Console.WriteLine("Введите массив");
            for (int i = 0; i < arl; i++)
            {
                int nmr = int.Parse(Console.ReadLine());
                nar[i] = nmr;
            }


            int pmb = nar[0];
            int rct = 0;

            for (int i = 1; i < nar.Length; i++)
            {

                if (nar[i] == pmb)
                {
                    rct++;
                }

                pmb = nar[i];
            }


            if (rct == nar.Length - 1)
            {

                int[] rea = new int[1] { nar[0] };
                Console.WriteLine(string.Join(" ", rea));
            }
            else
            {

                int[] rea = new int[nar.Length - rct];


                pmb = nar[0];
                rea[0] = nar[0];
                int cpt = 1;


                for (int i = 1; i < nar.Length; i++)
                {

                    if (nar[i] != pmb)
                    {
                        rea[cpt] = nar[i];
                        pmb = nar[i];
                        cpt++;
                    }
                }

                Console.WriteLine(string.Join(" ", rea));





                Console.ReadKey();



        }
        }
    }

     
}

