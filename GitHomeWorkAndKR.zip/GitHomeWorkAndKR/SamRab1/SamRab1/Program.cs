﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;

namespace SamRab1
{
    internal class Program
    {
        //1
        static int NextEven(int n)
        {
            if (n % 2 == 0)
                return n + 2;
            else
                return n + 1;
        }
        //2
        static string TriangleType(int a, int b, int c)
        {
                int[] sides = { a, b, c };
                Array.Sort(sides);
                a = sides[0];
                b = sides[1];
                c = sides[2];

                int a2 = a * a, b2 = b * b, c2 = c * c;
                if (a2 + b2 == c2)
                    return "right";
                else if (a2 + b2 > c2)
                    return "acute";
                else
                    return "obtuse";
           
        }
        //3
        static int SumSquares(int n)
        {
            int sum = 0;
            for (int i = 0; i < n; i++)
            {
                sum += i * i;
            }
            return sum;
        }
        //4
        static int CountGreaterThan(int[] arr, int x)
        {
            int count = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] > x)
                {
                    count++;
                }
            }
            return count;
        }
        //5
        static int Increase(ref int x, in int delta = 1)
        {
            x = x + delta;
            return x;
        }
        //6
        static bool AllPositive(int[] arr)
        {
            for (int i = 0; i < arr.Length; ++i)
            {
                if (arr[i] <= 0)
                {
                    return false;
                }

            }
            return true;
        }
        //7.
        static int[] MergeSorted(int[] a, int[] b)
        {
            int i = 0; 
            int j = 0; 
            int k = 0; 

            int[] result = new int[a.Length + b.Length];
         
            while (i < a.Length && j < b.Length)
            {
                if (a[i] < b[j])
                {
                    result[k] = a[i];
                    i++;
                }
                else
                {
                    result[k] = b[j];
                    j++;
                }
                k++;
            }
           
            while (i < a.Length)
            {
                result[k] = a[i];
                i++;
                k++;
            }
         
            while (j < b.Length)
            {
                result[k] = b[j];
                j++;
                k++;
            }

            return result;
        }


        static void Main ()
            {
                ////1)
                //Console.WriteLine("Задание 1");
                //Console.WriteLine("Введите число");
                //int n = int.Parse(Console.ReadLine());
                //Console.WriteLine("Ответ: " + NextEven(n));
                //Console.WriteLine();
                ////2)
                //Console.WriteLine("Задание 2");
                //Console.Write("Введите стороны a, b, c: ");
                //string[] t = Console.ReadLine().Split();
                //Console.WriteLine("Тип треугольника: " + TriangleType(int.Parse(t[0]), int.Parse(t[1]), int.Parse(t[2])));
                //Console.WriteLine();
                ////3)
                //Console.WriteLine("Задание 3");
                //Console.WriteLine("Введите число");
                //n = int.Parse(Console.ReadLine());
                //Console.WriteLine("Сумма квадратов: " + SumSquares(n));
                //Console.WriteLine();
                ////4)
                //Console.WriteLine("Задание 4");
                //Console.Write("Введите количество элементов массива: ");
                //int size = int.Parse(Console.ReadLine());
                //int[] arr = new int[size];
                //for (int i = 0; i < size; i++)
                //{
                //    Console.Write("arr[" + i + "] = ");
                //    arr[i] = int.Parse(Console.ReadLine());
                //}
                //Console.Write("Введите число: ");
                //int x = int.Parse(Console.ReadLine());
                //Console.WriteLine("Количество элементов больше x: " + CountGreaterThan(arr, x));
                //Console.WriteLine();
                ////5)
                //Console.WriteLine("Задание 5");
                //Console.Write("Введите число: ");
                //int val = int.Parse(Console.ReadLine());
                //Console.Write("Введите delta: ");
                //string deltaIt = Console.ReadLine();
                //if (deltaIt == "")
                //{
                //    Increase(ref val);
                //}
                //else
                //{
                //    int d = int.Parse(deltaIt);
                //    Increase(ref val, d);
                //}
                //Console.WriteLine("Новое значение = " + val);
                //Console.WriteLine();
                ////6)
                //Console.WriteLine("Задание 6");
                //Console.Write("Введите количество элементов массива: ");
                //size = int.Parse(Console.ReadLine()); 
                //arr = new int[size];
                //for (int i = 0; i < size; i++)
                //{
                //    Console.Write("arr[" + i + "] = ");
                //    arr[i] = int.Parse(Console.ReadLine());
                //}
                //Console.WriteLine(AllPositive(arr));
                //Console.WriteLine();


            //7)
            Console.WriteLine("Задание 7");
            Console.Write("Введите количество элементов первого массива: ");
            int sizeA = int.Parse(Console.ReadLine());
            int[] a = new int[sizeA];
            for (int i = 0; i < sizeA; i++)
            {
                Console.Write("a[" + i + "] = ");
                a[i] = int.Parse(Console.ReadLine());
            }

            Console.Write("Введите количество элементов второго массива: ");
            int sizeB = int.Parse(Console.ReadLine());
            int[] b = new int[sizeB];
            for (int i = 0; i < sizeB; i++)
            {
                Console.Write("b[" + i + "] = ");
                b[i] = int.Parse(Console.ReadLine());
            }
            int[] merged = MergeSorted(a, b);

            Console.Write("Результат слияния: ");
            for (int i = 0; i < merged.Length; i++)
            {
                Console.Write(merged[i] + " ");
            }
            Console.WriteLine();


            Console.ReadKey();


        }
    }





    }

