﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamWork2
{
    public class Building
    {
        private string _name;
        private int _buildCost;
        private int _production;
        public string Name => _name;
        public int BuildCost => _buildCost;
        public int Production => _production;

        public Building(string name, int buildCost, int production)
        {
            if (string.IsNullOrWhiteSpace(name))
                throw new ArgumentException("Название не может быть пустым");

            if (buildCost <= 0)
                throw new ArgumentException("Стоимость должна быть положительной");

            if (production < 0)
                throw new ArgumentException("Производство не может быть отрицательным");

            _name = name.Trim();
            _buildCost = buildCost;
            _production = production;
        }

        public void DisplayInfo()
        {
            Console.WriteLine($"Название: {_name}, Стоимость: {_buildCost}, Производство: {_production} в минуту");
        }
    }
}
