﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamWork2
{
    public class GameManager
    {
        private Settlement _settlement;
        private int _gameTime;

        public GameManager(Settlement settlement, int gameTime)
        {
            if (settlement == null)
                throw new ArgumentNullException(nameof(settlement), "Поселение не может быть null");

            if (gameTime <= 0)
                throw new ArgumentException("Время должно быть положительным");

            _settlement = settlement;
            _gameTime = gameTime;
        }
        public void SimulateProduction()
        {
            Console.WriteLine("Симуляция производства");
            Console.WriteLine($"Время симуляции: {_gameTime} минут");

            int totalProduction = _settlement.GetTotalProduction();
            int totalResources = totalProduction * _gameTime;

            Console.WriteLine($"Суммарное производство в минуту: {totalProduction}");
            Console.WriteLine($"Общий объем ресурсов за {_gameTime} минут: {totalResources}");

            if (totalResources > 0)
            {
                Console.WriteLine($"Или примерно {totalResources / 60} ресурсов в час");
            }
        }
    }
}