﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamWork2
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Симулятор");
            
            try
            {
                Console.WriteLine("Создание зданий");
                Console.WriteLine("Создайте 2 здания:");
                
                Building[] buildingsArray = new Building[2];
                
                for (int i = 0; i < 2; i++)
                {
                    Console.WriteLine($"Здание {i + 1}:");
                    buildingsArray[i] = CreateBuildingFromInput();
                    Console.WriteLine();
                }
                
                Console.WriteLine("Созданные здания");
                foreach (var building in buildingsArray)
                {
                    building.DisplayInfo();
                }

                Console.WriteLine("Создание поселения");
                int budget = GetValidInput("Введите начальный бюджет поселения: ", 0, 10000);
                Settlement mySettlement = new Settlement(budget);
                Console.WriteLine($"Создано поселение с бюджетом: {mySettlement.Budget}");

                Console.WriteLine("Добавление построек в поселение");
                Console.WriteLine($"Максимум можно построить {Settlement.MaxBuildings} зданий");
                
                bool addMore = true;
                while (addMore && mySettlement.BuildingCount < Settlement.MaxBuildings)
                {
                    Console.WriteLine("Хотите добавить новое здание? (да/нет)");
                    string response = Console.ReadLine()?.ToLower().Trim();
                    
                    if (response == "да" || response == "д" || response == "yes" || response == "y")
                    {
                        Console.WriteLine("Создание нового здания для поселения:");
                        Building newBuilding = CreateBuildingFromInput();
                        mySettlement.AddBuilding(newBuilding);
                        
                        if (mySettlement.BuildingCount >= Settlement.MaxBuildings)
                        {
                            Console.WriteLine("Достигнут лимит построек");
                            break;
                        }
                    }
                    else
                    {
                        addMore = false;
                    }
                }
                
                Console.WriteLine($"Итоговое производство поселения: {mySettlement.GetTotalProduction()} в минуту");
                Console.WriteLine("Симуляция производства");
                int simulationTime = GetValidInput("Введите время симуляции в минутах: ", 1, 10000);
                GameManager gameManager = new GameManager(mySettlement, simulationTime);

                Console.WriteLine();
                mySettlement.ShowBuildings();
                gameManager.SimulateProduction();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Ошибка: {ex.Message}");
            }
            
            Console.WriteLine("Конец");
            Console.WriteLine("Нажмите любую клавишу для выхода...");
            Console.ReadKey();
        }
        
        static Building CreateBuildingFromInput()
        {
            while (true)
            {
                try
                {
                    Console.Write("Введите название здания: ");
                    string name = Console.ReadLine()?.Trim();
                    
                    int cost = GetValidInput("Введите стоимость постройки: ", 1, 10000);
                    int production = GetValidInput("Введите производство в минуту (0 если не производит): ", 0, 1000);
                    
                    return new Building(name, cost, production);
                }
                catch (ArgumentException ex)
                {
                    Console.WriteLine($"Ошибка: {ex.Message}");
                    Console.WriteLine("Попробуйте ещё раз.");
                }
            }
        }

        static int GetValidInput(string prompt, int minValue, int maxValue)
        {
            while (true)
            {
                Console.Write(prompt);
                string input = Console.ReadLine();
                
                if (int.TryParse(input, out int result))
                {
                    if (result >= minValue && result <= maxValue)
                    {
                        return result;
                    }
                    else
                    {
                        Console.WriteLine($"Ошибка: число должно быть от {minValue} до {maxValue}");
                    }
                }
                else
                {
                    Console.WriteLine("Ошибка: введите целое число");
                }
            }
        }
    }
}