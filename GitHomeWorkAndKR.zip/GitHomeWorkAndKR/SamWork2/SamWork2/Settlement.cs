﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SamWork2
{
    public class Settlement
    {
        private Building[] _buildings;
        private int _budget;
        private int _buildingCount;
        public const int MaxBuildings = 5;

        public int Budget => _budget;
        public int BuildingCount => _buildingCount;

        public Settlement(int initialBudget)
        {
            if (initialBudget < 0)
                throw new ArgumentException("Бюджет не может быть отрицательным");

            _buildings = new Building[MaxBuildings];
            _budget = initialBudget;
            _buildingCount = 0;
        }
        public bool AddBuilding(Building building)
        {
            if (building == null)
            {
                Console.WriteLine("Ошибка: здание не существует");
                return false;
            }
            if (_buildingCount >= MaxBuildings)
            {
                Console.WriteLine($"Ошибка: нет свободных слотов (максимум {MaxBuildings})");
                return false;
            }
            if (_budget < building.BuildCost)
            {
                Console.WriteLine($"Ошибка: недостаточно средств. Нужно: {building.BuildCost}, есть: {_budget}");
                return false;
            }

            _buildings[_buildingCount] = building;
            _buildingCount++;

            _budget -= building.BuildCost;

            Console.WriteLine($"Здание '{building.Name}' успешно построено!");
            Console.WriteLine($"Остаток бюджета: {_budget}");

            return true;
        }
        public int GetTotalProduction()
        {
            int total = 0;
            for (int i = 0; i < _buildingCount; i++)
            {
                if (_buildings[i] != null)
                {
                    total += _buildings[i].Production;
                }
            }
            return total;
        }

        public void ShowBuildings()
        {
            Console.WriteLine("Список построек");

            if (_buildingCount == 0)
            {
                Console.WriteLine("Построек нет");
                return;
            }

            for (int i = 0; i < _buildingCount; i++)
            {
                if (_buildings[i] != null)
                {
                    Console.Write($"{i + 1}. ");
                    _buildings[i].DisplayInfo();
                }
            }

            Console.WriteLine($"Всего построек: {_buildingCount}");
            Console.WriteLine($"Суммарное производство: {GetTotalProduction()} в минуту");
            Console.WriteLine($"Текущий бюджет: {_budget}");
            Console.WriteLine($"Свободных слотов: {MaxBuildings - _buildingCount}");
        }
    }
}