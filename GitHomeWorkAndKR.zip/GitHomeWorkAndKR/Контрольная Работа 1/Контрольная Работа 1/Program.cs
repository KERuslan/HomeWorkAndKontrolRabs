﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_1
{
    internal class Program
    {
        // Защита
        static int InputNumber(string message)
        {
            while (true)
            {
                Console.Write(message + " ");
                string input = Console.ReadLine();

                if (int.TryParse(input, out int number))
                {
                    return number;
                }
                Console.WriteLine("Ошибка! Введите целое число.");
            }
        }
        static double InputDouble(string message)
        {
            while (true)
            {
                Console.Write(message + " ");
                string input = Console.ReadLine();
                input = input.Replace('.', ',');

                if (double.TryParse(input, out double number))
                {
                    return number;
                }
                Console.WriteLine("Ошибка! Введите число.");
            }
        }
        static int[] InputArray()
        {
            while (true)
            {
                Console.WriteLine("Введите элементы массива целых чисел через пробел:");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка! Пустой ввод.");
                    continue;
                }

                string[] parts = input.Split(' ');
                int[] numbers = new int[parts.Length];
                bool error = false;

                for (int i = 0; i < parts.Length; i++)
                {
                    if (!int.TryParse(parts[i], out numbers[i]))
                    {
                        Console.WriteLine($"Ошибка! '{parts[i]}' - не число.");
                        error = true;
                        break;
                    }
                }

                if (!error) return numbers;
            }
        }
        static double[] InputDoubleArray()
        {
            while (true)
            {
                Console.WriteLine("Введите элементы вещественного массива через пробел:");
                string input = Console.ReadLine();

                if (string.IsNullOrWhiteSpace(input))
                {
                    Console.WriteLine("Ошибка! Пустой ввод.");
                    continue;
                }

                string[] parts = input.Split(' ');
                double[] numbers = new double[parts.Length];
                bool error = false;

                for (int i = 0; i < parts.Length; i++)
                {
                    string part = parts[i].Replace('.', ',');
                    if (!double.TryParse(part, out numbers[i]))
                    {
                        Console.WriteLine($"Ошибка! '{parts[i]}' - не число.");
                        error = true;
                        break;
                    }
                }

                if (!error) return numbers;
            }
        }


        // 1.1
        static void Cns(int[] arr, ref int positive, ref int negative, ref int zero)
        {
            foreach (int num in arr)
            {
                if (num > 0)
                    positive++;
                else if (num < 0)
                    negative++;
                else
                    zero++;
            }
        }
        // 1.2
        static void Ces(int[] arr, ref double sum, ref double avr)
        {
            int cnt = 0;
            foreach (int num in arr)
            {
                if (num % 2 == 0) 
                {
                    sum += num;
                    cnt++;
                }
            }

            if (cnt > 0)
                avr = sum / cnt;
            else
                avr = 0;
        }
        // 1.3
        static int Caa(int[] arr)
        {
            
            double sum = 0;
            foreach (int num in arr)
                sum += num;
            double average = sum / arr.Length;

           
            int count = 0;
            foreach (int num in arr)
            {
                if (num > average)
                    count++;
            }

            return count;
        }
        // 1.4
        static void Fmmr(int[] arr, out int min, out int max, out int range)
        {
            min = arr[0];
            max = arr[0];

            foreach (int num in arr)
            {
                if (num < min)
                    min = num;
                if (num > max)
                    max = num;
            }

            range = max - min;
        }


        // 4.1
        static void Swap(ref int a, ref int b)
        {
            int temp = a;
            a = b;
            b = temp;
        }
        // 4.2
        static void GetStats(int[] arr, out double min, out double max, out double average)
        {
            min = arr[0];
            max = arr[0];
            double sum = 0;

            foreach (int num in arr)
            {
                if (num < min)
                    min = num;
                if (num > max)
                    max = num;
                sum += num;
            }

            average = sum / arr.Length;
        }
        // 4.3
        static bool Contains(int[] arr, int number)
        {
            foreach (int num in arr)
            {
                if (num == number)
                    return true;
            }
            return false;
        }
        // 4.4
        static void ScaleAndRound(double[] arr, double k, int digits = 0)
        {
            for (int i = 0; i < arr.Length; i++)
            {
                arr[i] = Math.Round(arr[i] * k, digits);
            }

        }

        // 3.1
        static int[] Faa(int[] arr, out int length)
        {
            if (arr.Length == 0)
            {
                length = 0;
                return new int[0];
            }

            double sum = 0;
            foreach (int num in arr)
                sum += num;
            double average = sum / arr.Length;

            int count = 0;
            foreach (int num in arr)
            {
                if (num > average)
                    count++;
            }

            int[] result = new int[count];
            int index = 0;

            foreach (int num in arr)
            {
                if (num > average)
                {
                    result[index] = num;
                    index++;
                }
            }

            length = count;
            return result;
        }

        // 2.1
        static void Fffli(int[] arr, int x, out int fIndex, out int lIndex)
        {
            fIndex = -1;
            lIndex = -1;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == x)
                {
                    if (fIndex == -1)
                        fIndex = i;
                    lIndex = i;
                }
            }
        }
        // 2.2
        static int[] Fai(int[] arr, int x)
        {
            int count = 0;
            foreach (int num in arr)
            {
                if (num == x)
                    count++;
            }

            int[] indices = new int[count];
            int index = 0;

            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == x)
                {
                    indices[index] = i;
                    index++;
                }
            }

            return indices;
        }
        //2.3
        static int Ra(int[] arr, int x, int y)
        {
            int count = 0;
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == x)
                {
                    arr[i] = y;
                    count++;
                }
            }
            return count;
        }



        static void Main(string[] args)
        {
        // Уровень 1 - Анализ массива
        Console.WriteLine("Уровень 1 - Анализ массива");

        // Массив 1-го уровня
        int[] ns = InputArray();
        Console.WriteLine("Ваш массив: [" + string.Join(", ", ns) + "]");
        Console.WriteLine();

       

        // 1)
        int pos = 0, neg = 0, zr = 0;
        Cns(ns, ref pos, ref neg, ref zr);
        Console.WriteLine($"Положительных чисел: {pos}");
        Console.WriteLine($"Отрицательных чисел: {neg}");
        Console.WriteLine($"Нулевых чисел: {zr}");

        // 2)
        double sumEven = 0, avrEven = 0;
        Ces(ns, ref sumEven, ref avrEven);
        Console.WriteLine($"Сумма чётных: {sumEven}");
        Console.WriteLine($"Среднее чётных: {avrEven:F2}");

        // 3)
        int abAvr = Caa(ns);
        Console.WriteLine($"Элементов больше среднего: {abAvr}");

        // 4)

        int min, max, range;
        Fmmr(ns, out min, out max, out range);
        Console.WriteLine($"Мин. элемент: {min}");
        Console.WriteLine($"Макс. элемент: {max}");
        Console.WriteLine($"Разница: {range}");
        Console.WriteLine();

        // Уровень 4 - Методы и параметры 

        Console.WriteLine("Уровень 4 - Методы и параметры");

        // Массив 4-го уровня

        int[] ns4 = InputArray();
        Console.WriteLine("Ваш массив: [" + string.Join(", ", ns4) + "]");
        Console.WriteLine();

        // 1)

        int a = InputNumber("Введите a:");
        int b = InputNumber("Введите b:");
        Console.WriteLine($"До: a = {a}, b = {b}");
        Swap(ref a, ref b);
        Console.WriteLine($"После: a = {a}, b = {b}");

        // 2)

        double minVal, maxVal, avg;
        GetStats(ns4, out minVal, out maxVal, out avg);
        Console.WriteLine($"Статистика массива - Мин: {minVal}, Макс: {maxVal}, Среднее: {avg:F2}");


        // 3)

        int searchNumber = InputNumber("Введите число для проверки:");
        bool contains = Contains(ns4, searchNumber);
        Console.WriteLine($"Число {searchNumber} содержится в массиве: {contains}");

        // 4)

        double[] dArr = InputDoubleArray();
        double k = InputDouble("Введите коэффициент k:");
        int digits = InputNumber("Введите количество знаков после запятой:");
        
        Console.WriteLine($"До: [{string.Join(", ", dArr)}]");
        ScaleAndRound(dArr, k, digits);
        Console.WriteLine($"После: [{string.Join(", ", dArr)}]");
    
       
    
    
        

        // Уровень 3 - Фильтрация

        Console.WriteLine("Уровень 3 - Фильтрация");

        // Массив 3-го уровня

        int[] ns3 = InputArray();
        Console.WriteLine("Ваш массив: [" + string.Join(", ", ns3) + "]");
        Console.WriteLine();



        // 1)

        int fLength;
        int[] fArray = Faa(ns3, out fLength);
        Console.WriteLine($"Новый массив: [{string.Join(", ", fArray)}]");
        Console.WriteLine($"Длина нового массива: {fLength}");
        Console.WriteLine();

        // Уровень 2 - Поиск, индексы и замена

        Console.WriteLine("Уровень 2 - Поиск, индексы и замена");

        // Массив 2-го уровня

        int[] ns2 = InputArray();
        Console.WriteLine("Ваш массив: [" + string.Join(", ", ns2) + "]");
        Console.WriteLine();


        // 1)

        int x = InputNumber("Введите число x для поиска:");
        int firstIndex, lastIndex;
        Fffli(ns2, x, out firstIndex, out lastIndex);
        Console.WriteLine($"Первый индекс: {firstIndex}");
        Console.WriteLine($"Последний индекс: {lastIndex}");

        // 2)

        int[] allIndices = Fai(ns2, x);
        Console.WriteLine($"Все индексы: [{string.Join(", ", allIndices)}]");
        int y = InputNumber("Введите число y для замены:");

        // 3)

        int replaceCount = Ra(ns2, x, y);
        Console.WriteLine($"Массив после замены: [{string.Join(", ", ns2)}]");
        Console.WriteLine($"Количество замен: {replaceCount}");
        
        Console.WriteLine();

        


        Console.ReadKey();

        }
    }
}
