﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Button : GameObject, IInteractable
    {
        private ITriggerable target;

        public Button(string name, ITriggerable triggerTarget) : base(name)
        {
            target = triggerTarget;
        }

        public string Interact(Player player)
        {
            if (!IsActive) return "Button is disabled";

            target.Trigger();
            return $"Button {Name} pressed";
        }

        public override string Info()
        {
            return $"Button: {Name} (ID: {Id}, Active: {IsActive})";
        }
    }
}