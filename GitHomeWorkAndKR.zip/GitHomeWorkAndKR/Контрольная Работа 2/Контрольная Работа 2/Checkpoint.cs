﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Checkpoint : GameObject, IInteractable
    {
        public Checkpoint(string name) : base(name) { }


        public string Interact(Player player)
        {
            if (!IsActive) return "Checkpoint is disabled";

            player.LastCheckpointId = Id;
            return $"Checkpoint {Name} saved";
        }

        public override string Info()
        {
            return $"Checkpoint: {Name} (ID: {Id}, Active: {IsActive})";
        }
    }
}
