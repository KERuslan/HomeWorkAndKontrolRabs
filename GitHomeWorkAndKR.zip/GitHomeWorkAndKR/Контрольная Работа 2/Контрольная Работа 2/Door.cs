﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Door : GameObject, IInteractable
    {
        private bool requiredAccess;

        public Door(string name, bool needsAccess) : base(name)
        {
            requiredAccess = needsAccess;
        }

        public string Interact(Player player)
        {
            if (!IsActive) return "Door is disabled";

            if (!requiredAccess || player.HasAccessCard)
                return "Door opened";
            else
                return "Access denied";
        }

        public override string Info()
        {
            return $"Door: {Name} (ID: {Id}, Active: {IsActive}, RequiresAccess: {requiredAccess})";
        }
    }
}