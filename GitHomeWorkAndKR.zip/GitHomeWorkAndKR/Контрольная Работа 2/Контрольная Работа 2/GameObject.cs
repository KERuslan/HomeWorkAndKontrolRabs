﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Remoting.Messaging;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public abstract class GameObject
    {

        private static int nextId = 1;
        public int Id { get; private set; }
        public string Name { get; set; }
        public bool IsActive { get; private set; } = true;

        public GameObject(string name)
        {
            Id = nextId++;
            Name = name;
        }

        public void Enable()
        {
            IsActive = true;
        }

        public void Disable()
        {
            IsActive = false;
        }

        public abstract string Info();
    }
}
    