﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public interface IDamageable
    {
        void ApplyDamage(int amount);

    }
}