﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Light : GameObject, ITriggerable
    {
        private bool isOn = false;

        public bool IsOn
        {
            get => isOn;
            private set => isOn = value;
        }

        public Light(string name) : base(name) { }

        public void Trigger()
        {
            IsOn = !IsOn;
            Console.WriteLine($"Light {Name} is now {(IsOn ? "ON" : "OFF")}");
        }

        public override string Info()
        {
            return $"Light: {Name} (ID: {Id}, Active: {IsActive}, IsOn: {IsOn})";
        }
    }
}