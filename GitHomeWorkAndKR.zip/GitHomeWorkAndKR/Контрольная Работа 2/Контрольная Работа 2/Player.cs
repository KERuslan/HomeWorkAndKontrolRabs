﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Player
    {

        public int Hp { get; set; } = 100;
        public bool HasAccessCard { get; set; } = false;
        public int LastCheckpointId { get; set; } = 0;


    }
}
