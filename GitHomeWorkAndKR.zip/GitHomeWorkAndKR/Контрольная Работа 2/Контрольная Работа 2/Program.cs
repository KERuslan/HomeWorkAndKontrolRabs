﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    class Program
    {
        static void Main(string[] args)
        {
            Scene scene = new Scene();
            Player player = new Player();

            scene.Objects.Add(new Door("Main Door", true));
            scene.Objects.Add(new Checkpoint("Start Point"));
            scene.Objects.Add(new Trap("Spike Trap"));

            Light light = new Light("Main Light");
            scene.Objects.Add(light);

            Button button = new Button("Light Switch", light);
            scene.Objects.Add(button);

            TimedTrap timedTrap = new TimedTrap("Delayed Trap", 3);
            scene.Objects.Add(timedTrap);

            bool running = true;

            while (running)
            {
                Console.WriteLine("Меню");
                Console.WriteLine("1.Показать все объекты");
                Console.WriteLine("2.Показать интерактивные объекты");
                Console.WriteLine("3.Взаимодействовать с объектом");
                Console.WriteLine("4.Отключить объект");
                Console.WriteLine("5.Включить объект");
                Console.WriteLine("6.Выполнить тик");
                Console.WriteLine("7.Дать карту доступа игроку");
                Console.WriteLine("8.Показать состояние игрока");
                Console.WriteLine("9.Выход");
                Console.Write("Выберите пункт: ");

                string input = Console.ReadLine();

                if (!int.TryParse(input, out int choice))
                {

                    Console.WriteLine("Введите число от 1 до 9");
                    continue;
                }

                switch (choice)
                {
                    case 1:
                        scene.PrintAll();
                        break;

                    case 2:
                        scene.PrintInteractive();
                        break;

                    case 3:
                        Console.Write("Введите ID объекта: ");
                        if (int.TryParse(Console.ReadLine(), out int interactId))
                            scene.InteractWith(interactId);
                        else
                            Console.WriteLine("Неверный ID");
                        break;

                    case 4:
                        Console.Write("Введите ID объекта для отключения: ");
                        if (int.TryParse(Console.ReadLine(), out int disableId))
                            scene.SetActive(disableId, false);
                        else
                            Console.WriteLine("Неверный ID");
                        break;

                    case 5:
                        Console.Write("Введите ID объекта для включения: ");
                        if (int.TryParse(Console.ReadLine(), out int enableId))
                            scene.SetActive(enableId, true);
                        else
                            Console.WriteLine("Неверный ID");
                        break;

                    case 6:
                        scene.Tick();
                        Console.WriteLine("Тик выполнен");
                        break;

                    case 7:
                        player.HasAccessCard = true;
                        Console.WriteLine("Игрок получил карту доступа");
                        break;

                    case 8:
                        Console.WriteLine($"Состояние игрока: HP={player.Hp}, " +
                            $"Карта доступа={player.HasAccessCard}, " +
                            $"Последний чекпоинт={player.LastCheckpointId}");
                        break;

                    case 9:
                        running = false;
                        Console.WriteLine("Выход из программы");
                        break;

                    default:
                        Console.WriteLine("!Введите число от 1 до 9!");
                        break;
                }
            }
        }
    }
}
