﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class Scene
    {


        public List<GameObject> Objects { get; private set; } = new List<GameObject>();
        private Player player = new Player();

        public void PrintAll()
        {
            Console.WriteLine("Все объекты на сцене");
            foreach (var obj in Objects)
            {
                Console.WriteLine(obj.Info());
            }

        }


        public void PrintInteractive()
        {
            Console.WriteLine("Интерактивные объекты");
            foreach (var obj in Objects)
            {
                if (obj is IInteractable)
                {
                    Console.WriteLine(obj.Info());
                }
            }
        }

        public void InteractWith(int id)
        {
            foreach (var obj in Objects)
            {
                if (obj.Id == id)
                {
                    if (obj is IInteractable interactable)
                    {
                        string result = interactable.Interact(player);
                        Console.WriteLine($"Результат взаимодействия - {result}");
                    }
                    else
                    {
                        Console.WriteLine("Объект не интерактивен");
                    }
                    return;
                }
            }
            Console.WriteLine("Объекта с таким ID не найден");
        }

        public void SetActive(int id, bool active)
        {
            foreach (var obj in Objects)
            {
                if (obj.Id == id)
                {
                    if (active) obj.Enable();
                    else obj.Disable();
                    Console.WriteLine($"Объект {obj.Name} теперь активен: {obj.IsActive}");
                    return;
                }
            }
            Console.WriteLine("Объекта с таким ID не найден");
        }
        public void Tick()
        {
            foreach (var obj in Objects)
            {
                if (obj is IUpdatable updatable)
                {
                    updatable.Update();
                }
            }
        }
    }
}
