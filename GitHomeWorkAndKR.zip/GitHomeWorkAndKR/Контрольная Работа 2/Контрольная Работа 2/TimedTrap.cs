﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{
    public class TimedTrap : Trap, IUpdatable
    {
        public int Delay { get; private set; }

        public TimedTrap(string name, int delay) : base(name)
        {
            Delay = delay;
            Disable();
        }

        public void Update()
        {
            if (Delay > 0)
            {
                Delay--;
                Console.WriteLine($"TimedTrap {Name}: до активации осталось {Delay} тиков");
                if (Delay == 0)
                {
                    Enable();
                    Console.WriteLine($"TimedTrap {Name} активирована!");
                }
            }
        }

        public override string Info()
        {
            return $"TimedTrap: {Name} (ID: {Id}, Active: {IsActive}, Damage: {Damage}, Delay: {Delay})";
        }
    }
}
