﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Контрольная_Работа_2
{

    public class Trap : GameObject, IInteractable, IDamageable
    {
        public int Damage { get; set; } = 15;

        public Trap(string name) : base(name) { }

        public string Interact(Player player)
        {
            if (!IsActive) return "Trap is disabled";

            player.Hp -= Damage;
            return $"Trap activated. Remaining HP - {player.Hp}";
        }

        public void ApplyDamage(int amount)
        {
            Disable();
        }

        public override string Info()
        {
            return $"Trap: {Name} (ID: {Id}, Active: {IsActive}, Damage: {Damage})";
        }
    }
}
